/* Host environment for the tti "Unicom" PBB 68020 boards */

#include "sparc/xm-sparc.h"

#define USG

#ifndef __GNUC__
#define USE_C_ALLOCA
#endif

