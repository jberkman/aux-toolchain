#include "sparc/xm-sysv4.h"

/* If not compiled with GNU C, include the system's <alloca.h> header.  */
#ifndef __GNUC__
#include <alloca.h>
#endif
