#define USG

#include "m68k/xm-m68k.h"
