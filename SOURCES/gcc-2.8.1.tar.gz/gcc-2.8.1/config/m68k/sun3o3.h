#include "m68k/sun3.h"

/* LINK_SPEC is needed only for SunOS 4.  */

#undef LINK_SPEC
