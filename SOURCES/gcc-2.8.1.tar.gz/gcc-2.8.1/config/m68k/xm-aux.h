#ifndef USG
#define USG
#endif

#ifndef AUX
#define AUX
#endif

#include "m68k/xm-m68k.h"
