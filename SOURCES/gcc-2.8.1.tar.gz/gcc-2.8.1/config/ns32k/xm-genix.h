/* Config file for ns32k running system V.  */

#include "ns32k/xm-ns32k.h"

#define USG
